"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
// Show UI with a default size that can be resized
figma.showUI(__html__, {
    width: 800,
    height: 600,
    themeColors: true
});
// Cache for library information
const libraryCache = new Map();
function getLibraryNameFromComponent(component) {
    return __awaiter(this, void 0, void 0, function* () {
        try {
            // Check cache first
            const componentKey = component.key;
            if (componentKey && libraryCache.has(componentKey)) {
                return libraryCache.get(componentKey);
            }
            // For remote components, try to import and get library info
            if (component.remote && componentKey) {
                try {
                    // importComponentByKeyAsync works for team libraries without API token
                    const importedComp = yield figma.importComponentByKeyAsync(componentKey);
                    if (importedComp) {
                        // Try to get library name from the component's parent structure
                        let currentNode = importedComp.parent;
                        // Walk up to find meaningful library name
                        while (currentNode) {
                            if (currentNode.type === 'PAGE') {
                                // Page name often contains the library name
                                const pageName = currentNode.name;
                                if (pageName && pageName !== 'Page 1') {
                                    const libName = pageName;
                                    libraryCache.set(componentKey, libName);
                                    return libName;
                                }
                            }
                            currentNode = currentNode.parent;
                        }
                        // If we got the component, at least return the component set name
                        if (importedComp.parent && importedComp.parent.type === 'COMPONENT_SET') {
                            const libName = importedComp.parent.name + ' Library';
                            libraryCache.set(componentKey, libName);
                            return libName;
                        }
                    }
                }
                catch (importError) {
                    // Import failed, try alternative method
                    console.log('Import failed:', importError);
                }
            }
            // Fallback: use component's parent name or component name
            if (component.parent && component.parent.type === 'COMPONENT_SET') {
                return component.parent.name + ' (External Library)';
            }
            // Final fallback: use a portion of the key as identifier
            if (componentKey) {
                const fileKey = componentKey.split(':')[0];
                return `Library (${fileKey.substring(0, 8)})`;
            }
            return 'Unknown Library';
        }
        catch (error) {
            console.error('Error getting library name:', error);
            return 'Unknown Library';
        }
    });
}
function findForeignComponents() {
    return __awaiter(this, void 0, void 0, function* () {
        const foreignComponents = [];
        const seenComponents = new Set(); // Track unique components to avoid duplicates
        const componentsToResolve = [];
        let processedCount = 0;
        let totalNodes = 0;
        // First pass: count total nodes for progress tracking
        function countNodes(node) {
            let count = 1;
            if ('children' in node) {
                for (const child of node.children) {
                    count += countNodes(child);
                }
            }
            return count;
        }
        totalNodes = countNodes(figma.currentPage);
        figma.ui.postMessage({
            type: 'debug',
            message: `Starting scan of ${totalNodes} nodes...`
        });
        // Recursively search through all nodes
        function traverse(node, path = "") {
            processedCount++;
            // Send progress update every 50 nodes
            if (processedCount % 50 === 0) {
                const progress = Math.round((processedCount / totalNodes) * 100);
                figma.ui.postMessage({
                    type: 'progress',
                    progress: progress,
                    message: `Scanning... ${processedCount}/${totalNodes} nodes`
                });
            }
            if (node.type === "INSTANCE") {
                const mainComponent = node.mainComponent;
                if (mainComponent && mainComponent.remote) {
                    // Create a unique key for deduplication
                    const uniqueKey = `${mainComponent.id}-${node.name}`;
                    if (seenComponents.has(uniqueKey)) {
                        return; // Skip duplicate
                    }
                    seenComponents.add(uniqueKey);
                    const componentSet = mainComponent.parent;
                    let libraryId = "";
                    // Get file key from component key
                    if (mainComponent.key) {
                        const keyParts = mainComponent.key.split(':');
                        if (keyParts.length >= 2) {
                            libraryId = keyParts[0];
                        }
                    }
                    const sourceComponentId = mainComponent.key ? mainComponent.key.split(':')[1] : undefined;
                    const componentInfo = {
                        name: node.name,
                        id: node.id,
                        sourceComponentSet: (componentSet === null || componentSet === void 0 ? void 0 : componentSet.type) === "COMPONENT_SET" ? componentSet.name : mainComponent.name,
                        path: path + "/" + node.name,
                        isRemote: true,
                        libraryName: "Loading...",
                        libraryId: libraryId,
                        masterComponentId: mainComponent.id,
                        masterComponentName: mainComponent.name,
                        sourceComponentId: sourceComponentId,
                        originalName: mainComponent.name
                    };
                    foreignComponents.push(componentInfo);
                    componentsToResolve.push({ comp: componentInfo, mainComponent });
                }
            }
            // Continue traversing if the node has children
            if ("children" in node) {
                const newPath = path + "/" + node.name;
                for (const child of node.children) {
                    traverse(child, newPath);
                }
            }
        }
        // Start traversing from the current page
        traverse(figma.currentPage);
        figma.ui.postMessage({
            type: 'debug',
            message: `Found ${foreignComponents.length} unique foreign components`
        });
        // Resolve library names for all components
        figma.ui.postMessage({
            type: 'debug',
            message: `Resolving library names for ${componentsToResolve.length} components...`
        });
        for (let i = 0; i < componentsToResolve.length; i++) {
            const { comp, mainComponent } = componentsToResolve[i];
            const libraryName = yield getLibraryNameFromComponent(mainComponent);
            comp.libraryName = libraryName;
            // Send progress update every 5 components
            if ((i + 1) % 5 === 0 || i === componentsToResolve.length - 1) {
                const progress = Math.round(((i + 1) / componentsToResolve.length) * 100);
                figma.ui.postMessage({
                    type: 'progress',
                    progress: progress,
                    message: `Resolving libraries... ${i + 1}/${componentsToResolve.length}`
                });
            }
        }
        figma.ui.postMessage({
            type: 'debug',
            message: `Resolved all library names`
        });
        return foreignComponents;
    });
}
// Listen for messages from the UI
figma.ui.onmessage = (msg) => __awaiter(void 0, void 0, void 0, function* () {
    if (msg.type === 'find-components') {
        try {
            const components = yield findForeignComponents();
            // Sort components by library name
            const sortedComponents = components.sort((a, b) => {
                const aLib = a.libraryName || 'Unknown Library';
                const bLib = b.libraryName || 'Unknown Library';
                if (aLib !== bLib) {
                    return aLib.localeCompare(bLib);
                }
                return a.masterComponentName.localeCompare(b.masterComponentName);
            });
            figma.ui.postMessage({
                type: 'foreign-components-found',
                components: sortedComponents
            });
            figma.ui.postMessage({
                type: 'debug',
                message: `Scan complete! Found ${components.length} foreign components.`
            });
        }
        catch (error) {
            figma.ui.postMessage({
                type: 'debug',
                message: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`
            });
        }
    }
    else if (msg.type === 'select-component' && msg.id) {
        const node = figma.getNodeById(msg.id);
        if (node) {
            figma.viewport.scrollAndZoomIntoView([node]);
            if ('selection' in figma.currentPage) {
                figma.currentPage.selection = [node];
            }
        }
    }
    // If the plugin command is canceled
    if (msg.type === 'cancel') {
        figma.closePlugin();
    }
});
