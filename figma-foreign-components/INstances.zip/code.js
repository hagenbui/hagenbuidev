"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
figma.showUI(__html__);
function findForeignComponents() {
    const foreignComponents = [];
    // Recursively search through all nodes in the document
    function traverse(node, path = "") {
        var _a;
        if (node.type === "INSTANCE") {
            const mainComponent = node.mainComponent;
            if (mainComponent) {
                // Check if the component is from another file
                const isRemote = mainComponent.remote;
                if (isRemote) {
                    foreignComponents.push({
                        name: node.name,
                        id: node.id,
                        sourceComponentSet: ((_a = mainComponent.parent) === null || _a === void 0 ? void 0 : _a.type) === "COMPONENT_SET" ? mainComponent.parent.name : undefined,
                        path: path + "/" + node.name,
                        isRemote: true
                    });
                }
            }
        }
        // Continue traversing if the node has children
        if ("children" in node) {
            const newPath = path + "/" + node.name;
            node.children.forEach(child => traverse(child, newPath));
        }
    }
    // Start traversing from the current page to avoid document-level issues
    traverse(figma.currentPage);
    // Send the results to the UI
    figma.ui.postMessage({
        type: 'foreign-components-found',
        components: foreignComponents
    });
}
// Listen for messages from the UI
figma.ui.onmessage = (msg) => __awaiter(void 0, void 0, void 0, function* () {
    if (msg.type === 'find-components') {
        findForeignComponents();
    }
    else if (msg.type === 'select-component' && msg.id) {
        const node = figma.getNodeById(msg.id);
        if (node) {
            figma.viewport.scrollAndZoomIntoView([node]);
            if ('selection' in figma.currentPage) {
                figma.currentPage.selection = [node];
            }
        }
    }
    // If the plugin command is canceled
    if (msg.type === 'cancel') {
        figma.closePlugin();
    }
});
